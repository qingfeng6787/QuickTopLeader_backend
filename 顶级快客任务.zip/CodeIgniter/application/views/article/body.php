<?php $this->load->view('article/header')?>
<body>
	<h1>php中文网-文章详情</h1>
	<div><?=$data?></div>
</body>
</html>