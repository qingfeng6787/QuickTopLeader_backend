<?php


class User_model extends CI_Model{

    public function userlist(){
        // 加载数据库的分组配置
        $this->load->database('default');
        // 选择表
        $this->db->from('user');
        // 查询字段
        $this->db->select('userId,username,email,phone');
        // 指定查询条件
        // 获取查询结果
        $query = $this->db->get();
        return json_encode($query->result_array());// 多条
    }

    public function detail($userid){
        if (empty($userid)){
            return json_encode("用户ID是空的");// 多条
        }
        // 加载数据库的分组配置
        $this->load->database('default');
        // 选择表
        $this->db->from('user');
        // 查询字段
        $this->db->select('userId,username,email,phone');
        // 指定查询条件
        $this->db->where(array('userId'=>$userid));
        // 获取查询结果
        $query = $this->db->get();
        //return  $query->row_array();// 单条
        return json_encode($query->row_array());// 多条
    }

    public function updateUserInfo($userid,$userInfokey,$userinValue){
//        if (empty($userid)){
//            return json_encode("用户ID是空的");// 多条
//        }
//        if(! is_int($userinValue)){
//            return json_encode('请输入信息');
//        }
        // 加载数据库的分组配置
        $this->load->database('default');
        // 选择表
        $this->db->from('user');
        // 查询字段
//        print_r($userInfokey);
//        switch ($userInfokey){
//            case 'phone':{
                $this->db->set('phone',$userinValue, false);
                $this->db->where('phone',$userinValue);
//            }break;
//            case 'email':{
//                $this->db->set('email',$userinValue, true);
//                $this->db->where('email',$userinValue);
//            }break;
//            case 'username':{
//                $this->db->set('username',$userinValue, true);
//                $this->db->where('username',$userinValue);
//            }break;
//        }

        $query = $this->db->get();
        $result =  $this->db->update('user',$this);
        if ($result === true){
            $this->load->database('default');
            // 选择表
            $this->db->from('user');
            // 查询字段
            $this->db->select('userId,username,email,phone');
            // 指定查询条件
            $this->db->where(array('userId'=>$userid));
            // 获取查询结果
            $query = $this->db->get();
//            return json_encode("更新成功");
            return json_encode($query->row_array());

        }else{
            return json_encode("更新失败");
        }
    }

    public function delete($userid){
        if (empty($userid)){
            return json_encode("用户ID是空的");// 多条
        }
        // 加载数据库的分组配置
        $this->load->database('default');
        // 选择表
        $this->db->from('user');
        $result = $this->db->delete('user', array('userId' => $userid));
        if ($result === true){

            $this->load->database('default');
            // 选择表
            $this->db->from('user');
            // 查询字段
            $this->db->select('userId,username,email,phone');
            // 获取查询结果
            $query = $this->db->get();
            return json_encode($query->result());
        }else{
            return json_encode("删除失败");
        }
    }

    public function insertOneUser($username,$email,$phone,$password){
        if (is_int($username)){
            return json_encode('用户名称不能全部为数字');
        }
        if (! is_numeric($phone)){
            return json_encode('请填写正确的手机号码');
        }
        if (empty($password)||empty($username)||empty($email)||empty($phone)){
            return json_encode('请完善信息');
        }
        // 加载数据库的分组配置
        $this->load->database('default');
        // 选择表
        $this->db->from('user');
        $data = array(
                'userName' => $username,
                'email' => $email,
                'phone' => $phone,
                'password'=> $password
        );

        try
        {
            // 如果抛出异常，以下文本不会输出
            $result  =  $this->db->insert('user', $data);
        }
        catch(Exception $e)
        {
            return json_encode("添加失败,请更换手机号码");
        }
        if ($result){

            $this->load->database('default');
            // 选择表
            $this->db->from('user');
            // 查询字段
            $this->db->select('userId,username,email,phone');
            $this->db->where(array('phone'=>$phone));
//            // 获取查询结果
//            $query = $this->db->get();
//            return json_encode($query->row_array());

//            $this->db->select('userId,username,email,phone');
            // 指定查询条件
            // 获取查询结果
            $query = $this->db->get();
            return json_encode($query->result_array());// 多条

        }else{
            return json_encode("添加失败");
        }

    }

//    public function login($username,$password){
//
//    }
//    public function loginout($username){
//    }
}
