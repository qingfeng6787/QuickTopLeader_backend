<?php
class Task_model extends CI_Model{

    public function tasklist(){
        // 加载数据库的分组配置
        $this->load->database('default');
        // 选择表
        $this->db->from('Task');
        // 查询字段
        $this->db->select('task_id,task_name,task_content,task_time,task_pregress');
        // 指定查询条件
        // 获取查询结果
        $query = $this->db->get();
        return json_encode($query->result_array());// 多条
    }

    public function detail($taskid){
        if (empty($taskid)){
            return json_encode("任务ID是空的");// 多条
        }
        // 加载数据库的分组配置
        $this->load->database('default');
        // 选择表
        $this->db->from('Task');
        // 查询字段
        $this->db->select('task_id,task_name,task_content,task_time,task_pregress,task_status');
        // 指定查询条件
        $this->db->where(array('task_id'=>$taskid));
        // 获取查询结果
        $query = $this->db->get();
        //return  $query->row_array();// 单条
        return json_encode($query->row_array());// 多条
    }

    public function updateTaskInfo($taskid,$key,$Value){
        if (empty($taskid)){
            return json_encode("任务ID是空的");// 多条
        }
        if(empty($Value)){
            return json_encode('请输入信息');
        }
        // 加载数据库的分组配置
        $this->load->database('default');
        // 选择表
        $this->db->from('Task');
        // 查询字段

        $this->db->set('task_name',$Value, false);
        $this->db->where('task_name',$Value);
//        $query = $this->db->get();
        $result =  $this->db->update('Task',$this);
        if ($result === true){
            $this->load->database('default');
            // 选择表
            $this->db->from('Task');
            // 查询字段
            $this->db->select('task_id,task_name,task_content,task_time,task_pregress,task_status');
            // 指定查询条件
            $this->db->where(array('task_id'=>$taskid));
            // 获取查询结果
            $query = $this->db->get();
//            return json_encode("更新成功");
            return json_encode($query->row_array());

        }else{
            return json_encode("更新失败");
        }
    }

    public function delete($taskid){
        if (empty($taskid)){
            return json_encode("用户ID是空的");// 多条
        }
        // 加载数据库的分组配置
        $this->load->database('default');
        // 选择表
        $this->db->from('Task');
        $result = $this->db->delete('Task', array('task_id' => $taskid));
        if ($result === true){

            $this->load->database('default');
            // 选择表
            $this->db->from('Task');
            // 查询字段
            $this->db->select('task_id,task_name,task_content,task_time,task_pregress,task_status');
            // 获取查询结果
            $query = $this->db->get();
            return json_encode($query->result());
        }else{
            return json_encode("删除失败");
        }
    }

    public function insertOneUser($taskName,$taskContent,$taskTime,$taskPregress){
        if (is_int($taskName)){
            return json_encode('用户名称不能全部为数字');
        }
//        if (! is_numeric($phone)){
//            return json_encode('请填写正确的手机号码');
//        }
        if (empty($taskContent)||empty($taskTime)||empty($taskPregress)){
            return json_encode('请完善信息');
        }
        // 加载数据库的分组配置
        $this->load->database('default');
        // 选择表
        $this->db->from('Task');
        $data = array(
            'task_name' => $taskName,
            'task_content' => $taskContent,
            'task_time' => $taskTime,
            'task_pregress'=> $taskPregress
        );

        try
        {
            // 如果抛出异常，以下文本不会输出
            $result  =  $this->db->insert('Task', $data);
        }
        catch(Exception $e)
        {
            return json_encode("添加失败,请更换手机号码");
        }
        if ($result){

            $this->load->database('default');
            // 选择表
            $this->db->from('Task');
            // 查询字段
            $this->db->select('task_id,task_name,task_content,task_time,task_pregress,task_status');
            $this->db->where(array('task_name'=>$taskName));
//            // 获取查询结果
//            $query = $this->db->get();
//            return json_encode($query->row_array());

//            $this->db->select('userId,username,email,phone');
            // 指定查询条件
            // 获取查询结果
            $query = $this->db->get();
            return json_encode($query->result_array());// 多条

        }else{
            return json_encode("添加失败");
        }

    }

//    public function login($username,$password){
//
//    }
//    public function loginout($username){
//    }
}
