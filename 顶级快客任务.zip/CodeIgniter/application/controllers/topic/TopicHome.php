<?php
class TopicHome extends CI_Controller{
    public function index()
    {
        echo "PHPAI 接口";
    }
}
