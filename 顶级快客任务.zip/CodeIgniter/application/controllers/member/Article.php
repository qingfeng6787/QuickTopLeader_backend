<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Article extends CI_Controller{
	public function index(){

		echo "PHP中文网";
		//$this->load->view('article/article_detail');
		//$this->load->view('article/header');
//		$this->data = '欢迎到php中文网学习PHP';
//		$view = $this->load->view('article/body',$this,true);
//		$view = 'phpcn'.$view;
//		echo $view;
	}

	public function detail(){
		// 加载模型
		//$this->load->model('article_model');
		// 调用模型中的方法
		$result = $this->article_model->detail(1);
//		echo '<pre>';
		print_r($result);
	}
}
