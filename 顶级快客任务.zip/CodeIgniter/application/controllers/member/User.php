<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class User extends CI_Controller
{

    /*根据ID查询*/
    public function detail($userid){
        // 加载模型
        $this->load->model('user_model');
        // 调用模型中的方法
        $result = $this->user_model->detail($userid);
//		echo '<pre>';
        print_r($result);
    }
    /* 列表查询 */
    public function userlist(){
        // 加载模型
        $this->load->model('user_model');
        // 调用模型中的方法
        $result = $this->user_model->userlist();
//		echo '<pre>';
        print_r($result);
    }
    /*更新数据*/
    public function updateUserInfo($userid,$key,$value){
        $this->load->model('user_model');
        $result = $this->user_model->updateUserInfo($userid,$key,$value);
        print_r($result);
    }
    public function delete($userId){
        $this->load->model('user_model');
        // 调用模型中的方法
        $result = $this->user_model->delete($userId);
        print_r($result);
    }

    public function insertOneUser($username,$email,$phone,$password){//,
        $this->load->model('user_model');
        $result = $this->user_model->insertOneUser($username,$email,$phone,$password);//,$password
        print_r($result);
    }

    public function login($username,$password){

    }
    public function logout($username,$password){

    }
}