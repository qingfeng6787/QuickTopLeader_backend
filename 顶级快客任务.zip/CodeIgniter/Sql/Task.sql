/*
 Navicat Premium Data Transfer

 Source Server         : 12312
 Source Server Type    : MySQL
 Source Server Version : 50726
 Source Host           : localhost:3306
 Source Schema         : apidata

 Target Server Type    : MySQL
 Target Server Version : 50726
 File Encoding         : 65001

 Date: 29/01/2021 15:21:12
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for Task
-- ----------------------------
DROP TABLE IF EXISTS `Task`;
CREATE TABLE `Task` (
  `task_id` int(20) NOT NULL AUTO_INCREMENT COMMENT '任务ID',
  `task_name` varchar(50) NOT NULL COMMENT '任务名称',
  `task_content` text NOT NULL,
  `task_time` date NOT NULL,
  `task_pregress` float NOT NULL,
  PRIMARY KEY (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

SET FOREIGN_KEY_CHECKS = 1;
